# Sample 03 - inspect after testing

Source documents reuse the previous layout and clinical course; identity, providers, addresses, contacts and request reference are new. No parser/model test was performed.

Medicine/regimen remain blank in the app until clinician entry. Source references below are fictional content, not treatment advice.

| Field | Source reference |
| --- | --- |
| Patient Family Name | Bennett |
| Patient Given Name | Daniel Aaron |
| Date of Birth | 1983/04/18 |
| PHN | MOCK-PHN-0136 |
| Presciber Name and Mailing Address | Dr. Sophia Grant / 420 Sample Avenue, Victoria BC V0V 0V0 |
| CPSBC or CRNBC Number | DEMO136 |
| Phone Number | 250-555-0162 |
| Fax Number | 250-555-0163 |
| Medication Requested | eltrombopag |
| Dose and Regimen | 25 mg orally once daily |
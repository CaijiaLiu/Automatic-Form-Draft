# Observed baseline on the harder EMR packet

Answer key SHA-256: `c14db732b0a9cd471a04da16b4e8aff3519eb203f7b21de4c85d243a29446ceb`

Identity merge blocked: False.
Exact matches among nonempty expected form fields: 3 / 8.
This is a deliberately difficult development fixture, not an independent model benchmark. Empty requested-drug/regimen fields are reported separately and do not inflate the nonempty-field result.

| Form field | Expected | Observed | Match |
| --- | --- | --- | --- |
| Patient Family Name | Park | (blank) | False |
| Patient Given Name | Evelyn Mei | (blank) | False |
| Date of Birth | 1978/11/23 | 1978/11/23 | True |
| PHN | MOCK-PHN-0042 | MOCK-PHN-0042 | True |
| Presciber Name and Mailing Address | Dr. Priya Chen / 250 Demonstration Avenue, Victoria BC V0V 0V0 | (blank) | False |
| CPSBC or CRNBC Number | DEMO042 | DEMO042 | True |
| Phone Number | 250-555-0134 | (blank) | False |
| Fax Number | 250-555-0135 | (blank) | False |
| Medication Requested | (blank / Requires Review) | (blank) | True |
| Dose and Regimen | (blank / Requires Review) | (blank) | True |

## Document processing

| File | Candidate facts | Recognized table rows |
| --- | ---: | ---: |
| 01_chart_snapshot.pdf | 1 | 0 |
| 02_cumulative_CBC.pdf | 2 | 0 |
| 03_medication_reconciliation_MAR.pdf | 0 | 0 |
| 04_hematology_followup_letter.pdf | 2 | 0 |
| 05_discharge_and_legacy_order.pdf | 1 | 0 |
| 06_amended_result_scan.pdf | 3 | 0 |
| 07_lab_history_export.csv | 0 | 0 |

## What still needs human assessment

- Correctly linking each CBC result to the collection date and specimen; no credit for finding a number alone.
- Replacing preliminary 22 with amended final 18 for D26-0514; no false extra visit.
- Combining the two actual IVIG administrations into one course, excluding the cancelled rituximab proposal.
- Separating tablet strength from prescribed daily dose; retaining uncertain prednisone stop date.
- Inferring the applicant from the signed-off clinician context and first-person plan, while excluding the referral recipient and discharge author.
- Associating the latest clinic contact with the applicant across files, without using the old office or patient contact.
- The current rules do not implement general semantic event resolution or robust cross-document role association. Missing rows or a plausible-looking paragraph do not demonstrate successful recognition.

Full evidence, warning messages and unedited candidates are in OBSERVED_BASELINE.json. Application extraction code was not changed for this packet.